gcc KeyGen.c -ltomcrypt -o CertificateAuthority
gcc Sign.c -ltomcrypt -lm -o Alice
gcc Verify.c -ltomcrypt -lm -o Bob

for i in 1 2
do
./CertificateAuthority Seed$i.txt 128 >> CA${i}128.log &
sleep 2
./Alice Message$i.txt SK.txt 128 36 >> Alice${i}128.log &
sleep 2
if [ "$i" -eq 1 ]; then
./Bob Message$i.txt Signature.txt PK.txt 50 128 36 >> Bob${i}128.log &
elif [ "$i" -eq 2 ]; then
./Bob Message$i.txt Signature.txt PK.txt 297 128 36 >> Bob${i}128.log &
sleep 2
fi
#=========================================
if cmp -s "SK.txt" "CorrectSK${i}t128.txt"
then
   echo "SK${i}t128 is valid."
else
   echo "SK${i}t128 does not match!"
fi 
#=========================================
if cmp -s "PK.txt" "CorrectPK${i}t128.txt"
then
   echo "PK${i}t128 is valid."
else
   echo "PK${i}t128 does not match!"
fi 
#=========================================
if cmp -s "Signature.txt" "CorrectSignature${i}t128.txt"
then
   echo "Signature${i}t128 is valid."
else
   echo "Signature${i}t128 does not match!"
fi 
#=========================================
echo "$(cat Verification.txt)"
#=========================================
echo "================================================="
done

for i in 1 2
do
./CertificateAuthority Seed$i.txt 1024 >> CA${i}1024.log
sleep 2
./Alice Message$i.txt SK.txt 1024 25 >> Alice${i}1024.log &
sleep 2
if [ "$i" -eq 1 ]; then
./Bob Message$i.txt Signature.txt PK.txt 50 1024 25 >> Bob${i}1024.log &
elif [ "$i" -eq 2 ]; then
./Bob Message$i.txt Signature.txt PK.txt 297 1024 25 >> Bob${i}1024.log &
sleep 2
fi
#=========================================
if cmp -s "SK.txt" "CorrectSK${i}t1024.txt"
then
   echo "SK${i}t1024 is valid."
else
   echo "SK${i}t1024 does not match!"
fi 
#=========================================
if cmp -s "PK.txt" "CorrectPK${i}t1024.txt"
then
   echo "PK${i}t1024 is valid."
else
   echo "PK${i}t1024 does not match!"
fi 
#=========================================
if cmp -s "Signature.txt" "CorrectSignature${i}t1024.txt"
then
   echo "Signature${i}t1024 is valid."
else
   echo "Signature${i}t1024 does not match!"
fi 
#=========================================
echo "$(cat Verification.txt)"
#=========================================
echo "================================================="
done
